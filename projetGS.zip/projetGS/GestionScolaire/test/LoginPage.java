import model.Connexion;
import view.Login;

// une page pour les tests
public class LoginPage {
    
    public static void main (String [] args ){
        
        
        String email = "fayediarra"; 
        String motPass = "030105";

        Connexion connexion = new Connexion();
        String profil = connexion.authentifier(email, motPass);

        if (profil != null) {
            System.out.println("L'utilisateur est authentifié avec le profil : " + profil);
        } else {
            System.out.println("L'authentification a échoué. Veuillez vérifier vos informations de connexion.");
        }

        // fichier principal pour la connexion Login.java
        
        Login log = new Login ();
        log.show();
    }
    
}




