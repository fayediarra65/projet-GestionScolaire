
package model;
import java.util.Date;
import java.time.Duration;

public class Cours {
    private int idCours ;
    private String nomCours;
    private  Date DateCours ;
    private Duration dureeCours;
    private Professeur prof;
     private Salle salleAssociee; // Référence vers la salle associée au cours
}

