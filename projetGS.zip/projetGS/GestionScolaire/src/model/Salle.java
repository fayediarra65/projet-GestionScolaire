
package model;
public class Salle {
        private int numeroSalle;
    
}
