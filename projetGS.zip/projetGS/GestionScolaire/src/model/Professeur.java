
package model;
public class Professeur {
    
}
