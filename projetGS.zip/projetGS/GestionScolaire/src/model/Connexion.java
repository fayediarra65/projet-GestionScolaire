package model;
import java.sql.*;

//chargons le pilote JDBC MySQL dans notre application Java.
public class Connexion {
      static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    // Méthode pour vérifier l'authentification et récupérer le profil de l'utilisateur
    public String authentifier (String email ,String motPass){
        String profil = null;
         // Vérification de l'existence d'un compte avec le login et le mot de passe fournis
        String query =" select u.profil from utilisateur u join compte c on c.id = u.id where c.email = ? && c.motPass = ? ";
        //creationd'une connexion
            try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gestionscolaire", "root", "030105");
                    PreparedStatement ps = con.prepareStatement(query)) {
                    ps.setString(1, email);
                    ps.setString(2, motPass);
            
                    try (ResultSet rs = ps.executeQuery()) {
                       if (rs.next()) {
                        profil = rs.getString("profil");
                    }
                }
            } catch (SQLException e) {
                
              }
        
            return profil;
        
    }
    public static void main(String[] args) {
        Connexion connexion = new Connexion();
        // mesidentifiants
        String email = "fayediarra65";
        String motPass = "030105";
        
        //recupérons le profil pour voir si la connecxion passe
        String profil = connexion.authentifier(email, motPass);
        
        if (profil != null) {
            System.out.println("Profil de l'utilisateur: " + profil);
        } else {
            System.out.println("Utilisateur non trouvé ou mot de passe incorrect.");
        }
    }

}

        
;

