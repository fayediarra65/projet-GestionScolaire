package model;
public class Compte {
    private String email , motPass;
    private Utilisateur user;    
}
