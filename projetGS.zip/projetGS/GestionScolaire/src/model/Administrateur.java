
package model;
public class Administrateur extends Utilisateur {  
}

