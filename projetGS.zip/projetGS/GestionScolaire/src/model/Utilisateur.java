package model;

public class Utilisateur {
    private int id;
    private String prenom , nom , profil;
   
}
