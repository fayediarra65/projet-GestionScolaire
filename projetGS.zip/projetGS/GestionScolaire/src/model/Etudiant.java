
package model;
public class Etudiant extends Utilisateur {
    
    
    private String filiere ; 
    // Méthode pour visualiser les notes
    public void visualiserNotes() {
    }
    // Méthode pour visualiser les cours
    public void visualiserCours() {
    }
}
