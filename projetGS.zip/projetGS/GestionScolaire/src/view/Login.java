package view;
import javax.swing.JOptionPane;
import model.Connexion;
public class Login extends javax.swing.JFrame {
    
    //les variables vont stocker nos valeurs
    private String emailUser;
    private String mdpUser;
    
    public Login() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        boutonQuitter = new javax.swing.JButton();
        boutonConnecter = new javax.swing.JButton();
        email = new javax.swing.JTextField();
        password = new javax.swing.JPasswordField();
        jLabel5 = new javax.swing.JLabel();

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/3.jpg"))); // NOI18N
        jLabel3.setText("jLabel3");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Gestion Scolaire");
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(160, 126, 23));

        jLabel6.setFont(new java.awt.Font("Chiller", 0, 36)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Authentification");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(183, 183, 183))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 10, 180, 60));

        jLabel2.setFont(new java.awt.Font("Mongolian Baiti", 0, 24)); // NOI18N
        jLabel2.setText("Login:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 110, 70, 30));

        jLabel4.setFont(new java.awt.Font("Mongolian Baiti", 0, 24)); // NOI18N
        jLabel4.setText("Mot De Passe:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 180, 170, 30));

        boutonQuitter.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        boutonQuitter.setText("Quitter");
        boutonQuitter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boutonQuitterActionPerformed(evt);
            }
        });
        getContentPane().add(boutonQuitter, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 280, 140, -1));

        boutonConnecter.setFont(new java.awt.Font("Rockwell", 0, 18)); // NOI18N
        boutonConnecter.setText("Se Connecter");
        boutonConnecter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boutonConnecterActionPerformed(evt);
            }
        });
        getContentPane().add(boutonConnecter, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 290, -1, -1));

        email.setText("fayediarra65");
        email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailActionPerformed(evt);
            }
        });
        getContentPane().add(email, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 110, 150, 30));

        password.setText("030105");
        password.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordActionPerformed(evt);
            }
        });
        getContentPane().add(password, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 170, 150, 30));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/C.jpg"))); // NOI18N
        jLabel5.setText("jLabel5");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(-50, -150, 660, 580));

        setBounds(0, 0, 575, 432);
    }// </editor-fold>//GEN-END:initComponents

    private void boutonQuitterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boutonQuitterActionPerformed
        // code pour quitter    
        email.setText("");
        password.setText("");
    }//GEN-LAST:event_boutonQuitterActionPerformed

    private void boutonConnecterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boutonConnecterActionPerformed
        // code pour se connecter
       try {
            // Récupération des valeurs saisies par l'utilisateur
        String emailUser = email.getText();
        String mdpUser = password.getText();
       
        // Appelons  la méthode d'authentification avec les valeurs saisies par l'utilisateur
        Connexion connexion = new Connexion();
        String profil = connexion.authentifier(emailUser, mdpUser);
        
        if (profil != null) {
               switch (profil) {
                   case "admin":
                        // Authentification réussie et profil admin, affichons la page d'accueil de l'administrateur
                        Login.super.dispose(); // Fermons  la fenêtre de connexion
                        new AdminPage().setVisible(true); // Affichons la page admin
                    break;
                    case "professeur":
                        // Authentification réussie et profil professeur, affichons la page correspondante
                        Login.super.dispose(); // Fermons la fenêtre de connexion
                        new Professeurpage().setVisible(true); // Affichons la page professeur
                    break;
                    case "etudiant" :
                        Login.super.dispose(); // Fermons la fenêtre de connexion
                        new Etudiant().setVisible(true); // Affichons la page professeur
                    break;
                    default:
                        //  un message d'erreur si le profil n'est pas reconnu
                        JOptionPane.showMessageDialog(null, "Profil non reconnu");
                    break;
               }
        }   
        else {
            // Affichons un message d'erreur si l'authentification échoue
            JOptionPane.showMessageDialog(null, "Email ou mot de passe incorrect");
        }
    } catch (Exception e) {
         // Gestion des exceptions
            System.out.println(e.getMessage());
            // Affichage d'un message d'erreur générique
            JOptionPane.showMessageDialog(null, "Une erreur s'est produite lors de l'authentification !");
    }
       
     
    }//GEN-LAST:event_boutonConnecterActionPerformed
    //retournons ce que l'utilisateur a saisi pour pouvoir les recupérer  et ramener dans d'autre pages;
    public String getEmailUser(){
        return emailUser;
     }
     public String getMdp(){
        return mdpUser;
     }
    private void emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailActionPerformed

    private void passwordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordActionPerformed
       
    }//GEN-LAST:event_passwordActionPerformed

   
    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton boutonConnecter;
    private javax.swing.JButton boutonQuitter;
    private javax.swing.JTextField email;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField password;
    // End of variables declaration//GEN-END:variables
}
