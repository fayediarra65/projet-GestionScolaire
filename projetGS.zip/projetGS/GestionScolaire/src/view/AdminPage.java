
package view;

 import java.sql.PreparedStatement;
 import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import view.Login;

public class AdminPage extends javax.swing.JFrame {

    /**
     * Creates new form AdminPage
     */
    public AdminPage() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        search = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        buttonAjout = new javax.swing.JButton();
        modify = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Page Admin");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("SimSun-ExtB", 2, 18)); // NOI18N
        jLabel1.setText("Gestion Des Comptes");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(205, 0, 194, 26));

        jLabel2.setFont(new java.awt.Font("Segoe UI Emoji", 2, 14)); // NOI18N
        jLabel2.setText("ID:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(45, 52, 83, 31));

        jLabel3.setFont(new java.awt.Font("Segoe UI Emoji", 2, 14)); // NOI18N
        jLabel3.setText("Prenom:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(35, 129, 83, 31));

        jLabel4.setFont(new java.awt.Font("Segoe UI Emoji", 2, 14)); // NOI18N
        jLabel4.setText("Nom:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(45, 91, 83, 31));

        jLabel5.setFont(new java.awt.Font("Segoe UI Emoji", 2, 14)); // NOI18N
        jLabel5.setText("Email:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(328, 49, 83, 31));

        jLabel6.setFont(new java.awt.Font("Segoe UI Emoji", 2, 14)); // NOI18N
        jLabel6.setText("profil:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(328, 129, 83, 31));

        jLabel7.setFont(new java.awt.Font("Segoe UI Emoji", 2, 14)); // NOI18N
        jLabel7.setText("filiere:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(328, 80, 83, 31));

        jLabel8.setFont(new java.awt.Font("Segoe UI Emoji", 2, 14)); // NOI18N
        jLabel8.setText("Mot de Passe:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(35, 174, 93, 31));

        search.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        search.setText("Rechercher");
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });
        getContentPane().add(search, new org.netbeans.lib.awtextra.AbsoluteConstraints(473, 255, 100, 48));

        delete.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        delete.setText("supprimer");
        getContentPane().add(delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 255, 100, 48));

        buttonAjout.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        buttonAjout.setText("Ajouter ");
        buttonAjout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonAjoutActionPerformed(evt);
            }
        });
        getContentPane().add(buttonAjout, new org.netbeans.lib.awtextra.AbsoluteConstraints(328, 195, -1, 48));

        modify.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        modify.setText("Modifier");
        modify.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modifyActionPerformed(evt);
            }
        });
        getContentPane().add(modify, new org.netbeans.lib.awtextra.AbsoluteConstraints(473, 195, 100, 48));

        jButton5.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jButton5.setText("gerer Qr code");
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(325, 255, 122, 48));
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(169, 89, 111, 31));

        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(169, 50, 111, 31));

        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(456, 87, 111, 31));

        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(169, 172, 111, 31));
        getContentPane().add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(456, 50, 111, 31));
        getContentPane().add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(169, 127, 111, 31));

        jTextField7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField7ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(456, 124, 111, 31));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "id", "prenom", "nom", "email", "filiere", "profil", "motPass"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 350, -1, 106));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/4.jpg"))); // NOI18N
        jLabel10.setText("jLabel10");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 460));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jTextField7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField7ActionPerformed

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4ActionPerformed

    private void buttonAjoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonAjoutActionPerformed
//        //code pour ajouter un compte 
//         // recupérons l'entrée de l'utilisateur dans la page login
//        Login log = new Login ();
//        String emailUser = log.getEmailUser();
//        String motDePasseUser  = log.getMdp();
//         
//        // Requête SQL SELECT pour vérifier si le compte n'existe pas déjà
//        String requete = "SELECT COUNT(*) AS compte_existe FROM compte WHERE email = ? AND mot_de_passe = ?";
//
//       try {
//        // Connexion à la base de données et préparation de la déclaration
//       
//            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gestionscolaire", "root", "030105");
//            PreparedStatement declaration = con.prepareStatement(requete);
//
//            // Définissons les paramètres de la requête préparée
//            declaration.setString(1, emailUser);
//            declaration.setString(2, motDePasseUser);
//
//            // Exécuter la requête
//            ResultSet resultat = declaration.executeQuery();
//
//             // Traitement du résultat
//            if (resultat.next()) {
//                int compteExiste = resultat.getInt("compte_existe");
//                 if (compteExiste > 0) {
//                // Le compte existe déjà
//                JOptionPane.showMessageDialog(null, "Le compte existe déjà");
//                } else {
//               // Requête SQL INSERT pour insérer les données dans la table utilisateur et creer son compte
//                String requeteInsertUtilisateur = "INSERT INTO utilisateur (nom, prenom, profil) VALUES (?, ?, ?)";
//                PreparedStatement declarationInsertUtilisateur = con.prepareStatement(requeteInsertUtilisateur);
//                declarationInsertUtilisateur.setString(1, "awa"); 
//                declarationInsertUtilisateur.setString(2, "Diop"); 
//                declarationInsertUtilisateur.setString(3, "Etudiant"); 
//                declarationInsertUtilisateur.executeUpdate();
//                declarationInsertUtilisateur.close();

                //    // Requête SQL INSERT pour insérer les données dans la table compte
                //    String requeteInsertCompte = "INSERT INTO compte (email, motPass) VALUES (?, ?)";
                //    PreparedStatement declarationInsertCompte = con.prepareStatement(requeteInsertCompte);
                //    declarationInsertCompte.setString(1, "diopAwa68");
                //    declarationInsertCompte.setString(2, "");
                //    declarationInsertCompte.executeUpdate();
                //    declarationInsertCompte.close();

                 // Affichons un message indiquant que le compte a été créé avec succès
//                JOptionPane.showMessageDialog(null, "Le compte a été créé avec succès");
//
//             }
//        }

//        // Fermons les ressources
//        resultat.close();
//        declaration.close();
//         con.close();
//    } catch (SQLException e) {
//        e.printStackTrace();  
//  

    }//GEN-LAST:event_buttonAjoutActionPerformed

   
    
    private void modifyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modifyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_modifyActionPerformed

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchActionPerformed

  
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buttonAjout;
    private javax.swing.JButton delete;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JButton modify;
    private javax.swing.JButton search;
    // End of variables declaration//GEN-END:variables
}
